#import "JCNotificationBannerPresenter.h"

@interface JCNotificationBannerPresenterIOS7Style : JCNotificationBannerPresenter
@property CGFloat bannerMaxWidth;
@property CGFloat bannerHeight;
@end
