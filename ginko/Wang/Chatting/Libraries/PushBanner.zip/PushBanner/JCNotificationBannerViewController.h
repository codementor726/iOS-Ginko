//
//  JCNotificationBannerViewController.h
//  GlobalDriver2ClientBooking
//
//  Created by James Coleman on 8/26/12.
//
//

#import <UIKit/UIKit.h>

@interface JCNotificationBannerViewController : UIViewController

@end
