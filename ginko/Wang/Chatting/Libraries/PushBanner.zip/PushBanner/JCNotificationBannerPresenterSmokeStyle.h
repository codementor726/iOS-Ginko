#import "JCNotificationBannerPresenter.h"

@interface JCNotificationBannerPresenterSmokeStyle : JCNotificationBannerPresenter
@property CGFloat minimumHorizontalMargin;
@property CGFloat bannerMaxWidth;
@property CGFloat bannerHeight;
@end
