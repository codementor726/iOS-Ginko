//
//  JCNotificationBannerViewController.m
//  GlobalDriver2ClientBooking
//
//  Created by James Coleman on 8/26/12.
//
//

#import "JCNotificationBannerViewController.h"

@interface JCNotificationBannerViewController ()

@end

@implementation JCNotificationBannerViewController

- (BOOL) shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
  // TODO: return result of main window's controller
  return YES;
}

@end
