#import "JCNotificationBannerPresenter.h"

@interface JCNotificationBannerPresenterIOSStyle : JCNotificationBannerPresenter

@end
