#import <UIKit/UIKit.h>

@interface JCNotificationBannerWindow : UIWindow

@property (nonatomic) UIView* bannerView;

@end
