#import "JCNotificationBannerView.h"

@interface JCNotificationBannerViewIOSStyle : JCNotificationBannerView

@end
