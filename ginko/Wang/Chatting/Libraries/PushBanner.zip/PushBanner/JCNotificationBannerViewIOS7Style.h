//
//  JCNotificationBannerViewIOS7Style.h
//  JCNotificationBannerPresenterDemo
//
//  Created by James Coleman on 1/5/14.
//  Copyright (c) 2014 James Coleman. All rights reserved.
//

#import "JCNotificationBannerView.h"

@interface JCNotificationBannerViewIOS7Style : JCNotificationBannerView

@end
